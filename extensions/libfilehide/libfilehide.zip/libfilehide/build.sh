#!/bin/sh
cd "${0%/*}"
g++ libfilehide.cpp -o libfilehide.dll -std=c++17 -static-libgcc -static-libstdc++ -static -shared

